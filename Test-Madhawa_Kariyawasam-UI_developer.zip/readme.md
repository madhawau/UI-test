Author: Madhawa Umanga Kariyawasam

@angular-devkit/architect       0.1200.4
@angular-devkit/build-angular   12.0.4
@angular-devkit/core            12.0.4
@angular-devkit/schematics      12.0.4
@schematics/angular             12.0.4
rxjs                            6.6.7
typescript                      4.2.4
Node				12.14.0	

Dependencies: 
Angulr route
scss/ BEM methodology
nxg-pagination


 